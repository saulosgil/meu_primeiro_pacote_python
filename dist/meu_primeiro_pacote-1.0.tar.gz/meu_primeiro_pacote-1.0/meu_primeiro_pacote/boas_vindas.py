def boas_vindas():
  print('Olá, seja bem-vindo(a)')
