# Criação Pacote - exemplo

Descrição de como o pacote funciona...

- Passos para instalação
- Outras informações importantes (autores, empresa, contato)
