# Criação de Pacote Python - exemplo

Descrição de como o pacote funciona...

- Passos para instalação
- Outras informações importantes (autores, empresa, contato)
